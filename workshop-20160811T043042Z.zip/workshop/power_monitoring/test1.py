import os
os.system("python /root/power_monitoring/sock_recv_cron.py 192.168.43.1")
print "done"
