#!/bin/sh
# variable : ip address


python -W ignore /root/power_monitoring/send_to_firebase.py 192.168.0.52&
